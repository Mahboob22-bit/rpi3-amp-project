/*
 * RPi3 AMP - Core 3 Launcher - FINAL VERSION
 *
 * With AGGRESSIVE cache management to ensure Core 3 sees our writes!
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>

#define BARE_METAL_BASE     0x20000000
#define CORE3_RELEASE_ADDR  0x000000F0

#define DEBUG_PRINT(fmt, ...) do { \
    printf(fmt, ##__VA_ARGS__); \
    fflush(stdout); \
} while(0)

/* ARM cache flush - try via syscall if available */
static void arm_cache_flush(void *addr, size_t len) {
#ifdef __aarch64__
    /* Use ARM cache maintenance instructions */
    uintptr_t start = (uintptr_t)addr & ~63UL;
    uintptr_t end = ((uintptr_t)addr + len + 63) & ~63UL;

    /* Clean (write-back) data cache to PoC (Point of Coherency) */
    for (uintptr_t va = start; va < end; va += 64) {
        asm volatile("dc cvac, %0" : : "r"(va) : "memory");
    }

    /* Data Synchronization Barrier */
    asm volatile("dsb sy" : : : "memory");

    /* Instruction Synchronization Barrier */
    asm volatile("isb" : : : "memory");
#endif
}

int main(int argc, char *argv[])
{
    int mem_fd = -1;
    void *bare_metal_mem = NULL;
    void *spin_table_mem = NULL;
    FILE *fp = NULL;
    struct stat st;
    size_t map_size;

    DEBUG_PRINT("========================================\n");
    DEBUG_PRINT("RPi3 AMP - Core 3 Launcher (FINAL)\n");
    DEBUG_PRINT("With AGGRESSIVE cache management!\n");
    DEBUG_PRINT("========================================\n\n");

    if (argc != 2) {
        DEBUG_PRINT("Usage: %s <binary_file>\n", argv[0]);
        return 1;
    }

    const char *binary_file = argv[1];

    /* Check binary file */
    DEBUG_PRINT("[1/6] Checking binary file: %s\n", binary_file);
    if (stat(binary_file, &st) != 0) {
        perror("ERROR: Cannot stat binary file");
        return 1;
    }
    DEBUG_PRINT("      Binary size: %ld bytes\n\n", st.st_size);

    if (st.st_size > 10*1024*1024) {
        DEBUG_PRINT("ERROR: Binary too large\n");
        return 1;
    }

    map_size = (st.st_size + 4095) & ~4095;

    /* Open /dev/mem with O_SYNC for uncached access */
    DEBUG_PRINT("[2/6] Opening /dev/mem (O_SYNC)...\n");
    mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mem_fd < 0) {
        perror("ERROR: Cannot open /dev/mem");
        return 1;
    }
    DEBUG_PRINT("      OK\n\n");

    /* Map bare-metal memory region */
    DEBUG_PRINT("[3/6] Mapping memory at 0x%08X...\n", BARE_METAL_BASE);
    bare_metal_mem = mmap(NULL,
                          map_size,
                          PROT_READ | PROT_WRITE,
                          MAP_SHARED,
                          mem_fd,
                          BARE_METAL_BASE);

    if (bare_metal_mem == MAP_FAILED) {
        perror("ERROR: mmap failed");
        close(mem_fd);
        return 1;
    }
    DEBUG_PRINT("      OK - mapped to %p\n\n", bare_metal_mem);

    /* Load binary file */
    DEBUG_PRINT("[4/6] Loading binary file...\n");
    fp = fopen(binary_file, "rb");
    if (!fp) {
        perror("ERROR: Cannot open binary file");
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    size_t bytes_read = fread(bare_metal_mem, 1, st.st_size, fp);
    fclose(fp);

    if (bytes_read != st.st_size) {
        DEBUG_PRINT("ERROR: Read %zu bytes, expected %ld\n", bytes_read, st.st_size);
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    DEBUG_PRINT("      OK - Loaded %zu bytes\n\n", bytes_read);

    /* AGGRESSIVE cache management for loaded binary */
    DEBUG_PRINT("[5/6] Flushing caches for loaded binary...\n");
    __sync_synchronize();
    msync(bare_metal_mem, map_size, MS_SYNC | MS_INVALIDATE);
    arm_cache_flush(bare_metal_mem, map_size);
    __sync_synchronize();
    DEBUG_PRINT("      OK - Caches flushed\n\n");

    /* Map spin table region - UNCACHED with O_SYNC */
    DEBUG_PRINT("[6/6] Waking Core 3 via spin table...\n");
    DEBUG_PRINT("      Spin table address: 0x%08X\n", CORE3_RELEASE_ADDR);

    spin_table_mem = mmap(NULL,
                          4096,
                          PROT_READ | PROT_WRITE,
                          MAP_SHARED,
                          mem_fd,
                          0);  // Map page 0

    if (spin_table_mem == MAP_FAILED) {
        perror("ERROR: Cannot map spin table");
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    volatile uint64_t *release_addr = (volatile uint64_t *)((char *)spin_table_mem + CORE3_RELEASE_ADDR);

    /* Read current value */
    uint64_t old_value = *release_addr;
    DEBUG_PRINT("      Current spin table value: 0x%016lX\n", old_value);

    /* Write entry point with MAXIMUM cache control */
    DEBUG_PRINT("      Writing entry point 0x%08X...\n", BARE_METAL_BASE);

    /* Multiple writes with barriers to ensure it gets through */
    *release_addr = (uint64_t)BARE_METAL_BASE;
    __sync_synchronize();
    asm volatile("dsb sy" : : : "memory");

    *release_addr = (uint64_t)BARE_METAL_BASE;
    __sync_synchronize();
    asm volatile("dsb sy" : : : "memory");

    /* Flush the specific cache line containing spin table */
    arm_cache_flush((void *)release_addr, 8);
    __sync_synchronize();

    /* Flush entire page to be sure */
    msync(spin_table_mem, 4096, MS_SYNC | MS_INVALIDATE);
    __sync_synchronize();
    asm volatile("dsb sy" : : : "memory");

    /* Read back to verify */
    uint64_t readback = *release_addr;
    DEBUG_PRINT("      Readback: 0x%016lX\n", readback);

    if (readback != BARE_METAL_BASE) {
        DEBUG_PRINT("      WARNING: Readback doesn't match! (got 0x%lX)\n", readback);
    } else {
        DEBUG_PRINT("      OK - Value written correctly\n");
    }

    /* Send MULTIPLE SEV events */
    DEBUG_PRINT("      Sending SEV events...\n");
    for (int i = 0; i < 10; i++) {
        asm volatile("sev" : : : "memory");
        __sync_synchronize();
        usleep(1000);  // 1ms between each
    }
    DEBUG_PRINT("      OK - 10x SEV sent\n\n");

    /* Wait a moment for Core 3 to start */
    DEBUG_PRINT("      Waiting for Core 3 to start...\n");
    usleep(500000);  // 500ms

    /* Check if spin table was cleared (Core 3 read it) */
    uint64_t final_value = *release_addr;
    DEBUG_PRINT("      Final spin table value: 0x%016lX\n", final_value);

    if (final_value == 0) {
        DEBUG_PRINT("      GOOD SIGN: Spin table cleared - Core 3 may have read it!\n");
    } else if (final_value == BARE_METAL_BASE) {
        DEBUG_PRINT("      Spin table still has our value - Core 3 may not have woken\n");
    } else {
        DEBUG_PRINT("      Spin table changed to different value: 0x%lX\n", final_value);
    }

    /* Cleanup */
    munmap(spin_table_mem, 4096);
    munmap(bare_metal_mem, map_size);
    close(mem_fd);

    DEBUG_PRINT("\n========================================\n");
    DEBUG_PRINT("Launcher completed!\n");
    DEBUG_PRINT("Check UART0 output (GPIO 14/15)\n");
    DEBUG_PRINT("If you see nothing, Core 3 didn't wake\n");
    DEBUG_PRINT("========================================\n");

    return 0;
}
