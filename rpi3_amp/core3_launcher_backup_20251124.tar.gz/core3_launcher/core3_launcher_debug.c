/*
 * RPi3 AMP - Core 3 Launcher - DEBUG VERSION
 * With extensive logging to find bus error
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

#define ARM_LOCAL_BASE      0x40000000
#define ARM_LOCAL_SIZE      0x1000
#define BARE_METAL_BASE     0x20000000
#define CORE3_MBOX3_SET     0xB0
#define CORE3_MBOX3_CLR     0xF0

#define DEBUG_PRINT(fmt, ...) do { \
    printf(fmt, ##__VA_ARGS__); \
    fflush(stdout); \
} while(0)

int main(int argc, char *argv[])
{
    int mem_fd = -1;
    void *bare_metal_mem = NULL;
    FILE *fp = NULL;
    struct stat st;
    size_t map_size;

    DEBUG_PRINT("====================================\n");
    DEBUG_PRINT("RPi3 AMP - Core 3 Launcher (DEBUG)\n");
    DEBUG_PRINT("====================================\n\n");

    if (argc != 2) {
        DEBUG_PRINT("Usage: %s <binary_file>\n", argv[0]);
        return 1;
    }

    const char *binary_file = argv[1];

    /* Step 1: Check binary file */
    DEBUG_PRINT("[DEBUG] Checking binary file: %s\n", binary_file);
    if (stat(binary_file, &st) != 0) {
        perror("ERROR: Cannot stat binary file");
        return 1;
    }
    DEBUG_PRINT("[DEBUG] Binary size: %ld bytes (0x%lX)\n", st.st_size, st.st_size);

    if (st.st_size > 10*1024*1024) {
        DEBUG_PRINT("ERROR: Binary too large\n");
        return 1;
    }

    /* Round up to page size (4096) */
    map_size = (st.st_size + 4095) & ~4095;
    DEBUG_PRINT("[DEBUG] Will map %zu bytes (0x%zX) - page aligned\n\n", map_size, map_size);

    /* Step 2: Open /dev/mem */
    DEBUG_PRINT("[1/5] Opening /dev/mem...\n");
    mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mem_fd < 0) {
        perror("ERROR: Cannot open /dev/mem");
        return 1;
    }
    DEBUG_PRINT("      OK\n\n");

    /* Step 3: Map only what we need (not full 10 MB) */
    DEBUG_PRINT("[2/5] Mapping %zu bytes at 0x%08X...\n", map_size, BARE_METAL_BASE);
    bare_metal_mem = mmap(NULL,
                          map_size,
                          PROT_READ | PROT_WRITE,
                          MAP_SHARED,
                          mem_fd,
                          BARE_METAL_BASE);

    if (bare_metal_mem == MAP_FAILED) {
        perror("ERROR: mmap failed");
        close(mem_fd);
        return 1;
    }
    DEBUG_PRINT("      OK - mapped to %p\n\n", bare_metal_mem);

    /* Step 4: Test write before loading file */
    DEBUG_PRINT("[DEBUG] Testing memory write...\n");
    volatile uint32_t *test = (volatile uint32_t *)bare_metal_mem;
    test[0] = 0x12345678;
    DEBUG_PRINT("[DEBUG] Wrote 0x12345678, read back: 0x%08X\n", test[0]);
    if (test[0] != 0x12345678) {
        DEBUG_PRINT("WARNING: Memory test failed!\n");
    }
    DEBUG_PRINT("[DEBUG] Memory is writable!\n\n");

    /* Step 5: Open binary file */
    DEBUG_PRINT("[3/5] Opening binary file...\n");
    fp = fopen(binary_file, "rb");
    if (!fp) {
        perror("ERROR: Cannot open binary file");
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }
    DEBUG_PRINT("      OK\n\n");

    /* Step 6: Read file in small chunks to avoid bus error */
    DEBUG_PRINT("[4/5] Loading binary in chunks...\n");
    size_t chunk_size = 256;  // Small chunks
    size_t total_read = 0;
    unsigned char *dest = (unsigned char *)bare_metal_mem;

    while (total_read < st.st_size) {
        size_t to_read = (st.st_size - total_read < chunk_size) ?
                         (st.st_size - total_read) : chunk_size;

        size_t n = fread(dest + total_read, 1, to_read, fp);
        if (n != to_read) {
            DEBUG_PRINT("ERROR: Read failed at offset %zu\n", total_read);
            fclose(fp);
            munmap(bare_metal_mem, map_size);
            close(mem_fd);
            return 1;
        }

        total_read += n;

        if (total_read % 256 == 0) {
            DEBUG_PRINT("      Progress: %zu / %ld bytes\r", total_read, st.st_size);
        }
    }

    fclose(fp);
    DEBUG_PRINT("\n      OK - Loaded %zu bytes\n\n", total_read);

    /* Memory barrier */
    __sync_synchronize();

    /* Step 7: Wake Core 3 */
    DEBUG_PRINT("[5/5] Waking Core 3...\n");

    int arm_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (arm_fd < 0) {
        perror("ERROR: Cannot open /dev/mem for ARM Local");
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    void *arm_local = mmap(NULL, ARM_LOCAL_SIZE, PROT_READ | PROT_WRITE,
                          MAP_SHARED, arm_fd, ARM_LOCAL_BASE);
    if (arm_local == MAP_FAILED) {
        perror("ERROR: Cannot map ARM Local");
        close(arm_fd);
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    volatile uint32_t *mbox_set = (volatile uint32_t *)(arm_local + CORE3_MBOX3_SET);
    volatile uint32_t *mbox_clr = (volatile uint32_t *)(arm_local + CORE3_MBOX3_CLR);

    DEBUG_PRINT("      Clearing mailbox...\n");
    *mbox_clr = 0xFFFFFFFF;
    __sync_synchronize();
    usleep(1000);

    DEBUG_PRINT("      Writing jump address 0x%08X...\n", BARE_METAL_BASE);
    *mbox_set = BARE_METAL_BASE;
    __sync_synchronize();

    DEBUG_PRINT("      Sending SEV...\n");
    asm volatile("sev");
    __sync_synchronize();

    DEBUG_PRINT("      OK\n\n");

    /* Cleanup */
    munmap(arm_local, ARM_LOCAL_SIZE);
    close(arm_fd);
    munmap(bare_metal_mem, map_size);
    close(mem_fd);

    DEBUG_PRINT("====================================\n");
    DEBUG_PRINT("SUCCESS! Core 3 should be running!\n");
    DEBUG_PRINT("Check UART0 output (GPIO 14/15)\n");
    DEBUG_PRINT("====================================\n");

    return 0;
}
