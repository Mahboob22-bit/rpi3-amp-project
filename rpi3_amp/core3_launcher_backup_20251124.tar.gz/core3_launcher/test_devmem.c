/*
 * Simple test: Can we access memory at 0x20000000 via /dev/mem?
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdint.h>

#define TEST_ADDR    0x20000000
#define TEST_SIZE    4096  // 1 page

int main(void)
{
    int fd;
    void *ptr;
    volatile uint32_t *test;

    printf("Test: /dev/mem access to 0x%08X\n\n", TEST_ADDR);

    // Open /dev/mem
    printf("[1] Opening /dev/mem...\n");
    fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd < 0) {
        perror("ERROR: Cannot open /dev/mem");
        return 1;
    }
    printf("    OK\n\n");

    // Try to map
    printf("[2] Mapping %d bytes at 0x%08X...\n", TEST_SIZE, TEST_ADDR);
    ptr = mmap(NULL, TEST_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, TEST_ADDR);
    if (ptr == MAP_FAILED) {
        perror("ERROR: mmap failed");
        close(fd);
        return 1;
    }
    printf("    OK - mapped to %p\n\n", ptr);

    // Try to write
    printf("[3] Writing test pattern...\n");
    test = (volatile uint32_t *)ptr;
    test[0] = 0xDEADBEEF;
    printf("    OK - wrote 0xDEADBEEF\n\n");

    // Try to read back
    printf("[4] Reading back...\n");
    uint32_t val = test[0];
    printf("    OK - read 0x%08X\n\n", val);

    if (val == 0xDEADBEEF) {
        printf("SUCCESS! Memory at 0x%08X is accessible!\n", TEST_ADDR);
    } else {
        printf("WARNING: Read value doesn't match (got 0x%08X, expected 0xDEADBEEF)\n", val);
    }

    munmap(ptr, TEST_SIZE);
    close(fd);

    return 0;
}
