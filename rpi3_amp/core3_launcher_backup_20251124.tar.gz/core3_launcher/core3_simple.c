/*
 * Simple Core 3 Launcher - Load via temp buffer to avoid bus error
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdint.h>

#define BARE_METAL_BASE     0x20000000
#define CORE3_RELEASE_ADDR  0x000000F0

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <binary>\n", argv[0]);
        return 1;
    }

    // Get file size
    struct stat st;
    if (stat(argv[1], &st) != 0) {
        perror("stat");
        return 1;
    }

    printf("[1/5] Loading %s (%ld bytes) into temp buffer...\n", argv[1], st.st_size);

    // Read file into temp buffer
    FILE *fp = fopen(argv[1], "rb");
    if (!fp) {
        perror("fopen");
        return 1;
    }

    unsigned char *buffer = malloc(st.st_size);
    if (!buffer) {
        perror("malloc");
        fclose(fp);
        return 1;
    }

    if (fread(buffer, 1, st.st_size, fp) != st.st_size) {
        printf("ERROR: fread failed\n");
        free(buffer);
        fclose(fp);
        return 1;
    }
    fclose(fp);
    printf("      OK\n\n");

    // Open /dev/mem
    printf("[2/5] Opening /dev/mem...\n");
    int fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd < 0) {
        perror("open /dev/mem");
        free(buffer);
        return 1;
    }
    printf("      OK\n\n");

    // Map memory at 0x20000000
    size_t map_size = (st.st_size + 4095) & ~4095;
    printf("[3/5] Mapping %zu bytes at 0x%08X...\n", map_size, BARE_METAL_BASE);

    void *mem = mmap(NULL, map_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, BARE_METAL_BASE);
    if (mem == MAP_FAILED) {
        perror("mmap");
        free(buffer);
        close(fd);
        return 1;
    }
    printf("      OK\n\n");

    // Copy buffer to mapped memory
    printf("[4/5] Copying binary to 0x%08X...\n", BARE_METAL_BASE);
    memcpy(mem, buffer, st.st_size);
    free(buffer);

    // Flush caches
    __sync_synchronize();
    msync(mem, map_size, MS_SYNC);
    __sync_synchronize();
    printf("      OK\n\n");

    // Map spin table
    printf("[5/5] Writing to spin table and waking Core 3...\n");
    void *spin = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (spin == MAP_FAILED) {
        perror("mmap spin table");
        munmap(mem, map_size);
        close(fd);
        return 1;
    }

    volatile uint64_t *release = (volatile uint64_t *)((char *)spin + CORE3_RELEASE_ADDR);

    printf("      Current spin table: 0x%016lX\n", *release);
    printf("      Writing 0x%08X...\n", BARE_METAL_BASE);

    // Write with barriers
    *release = (uint64_t)BARE_METAL_BASE;
    __sync_synchronize();
    asm volatile("dsb sy" ::: "memory");
    msync(spin, 4096, MS_SYNC);

    printf("      Readback: 0x%016lX\n", *release);

    // Send SEV
    printf("      Sending SEV...\n");
    for (int i = 0; i < 5; i++) {
        asm volatile("sev" ::: "memory");
        usleep(10000);
    }
    printf("      OK\n\n");

    usleep(200000);
    printf("      Final spin table: 0x%016lX\n", *release);

    munmap(spin, 4096);
    munmap(mem, map_size);
    close(fd);

    printf("\n========================================\n");
    printf("Done! Check UART for Core 3 output.\n");
    printf("========================================\n");

    return 0;
}
