/*
 * RPi3 AMP - Core 3 Launcher - FIXED VERSION
 *
 * Uses correct spin-table mechanism to wake Core 3
 * cpu-release-addr = 0x000000F0 (from device tree)
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

#define BARE_METAL_BASE     0x20000000
#define SPIN_TABLE_BASE     0x000000D8  // Base of spin table (Core 0-3)
#define CORE3_RELEASE_ADDR  0x000000F0  // Core 3 release address (0xD8 + 3*8)

#define DEBUG_PRINT(fmt, ...) do { \
    printf(fmt, ##__VA_ARGS__); \
    fflush(stdout); \
} while(0)

int main(int argc, char *argv[])
{
    int mem_fd = -1;
    void *bare_metal_mem = NULL;
    void *spin_table_mem = NULL;
    FILE *fp = NULL;
    struct stat st;
    size_t map_size;

    DEBUG_PRINT("====================================\n");
    DEBUG_PRINT("RPi3 AMP - Core 3 Launcher (FIXED)\n");
    DEBUG_PRINT("====================================\n\n");

    if (argc != 2) {
        DEBUG_PRINT("Usage: %s <binary_file>\n", argv[0]);
        return 1;
    }

    const char *binary_file = argv[1];

    /* Check binary file */
    DEBUG_PRINT("[1/5] Checking binary file: %s\n", binary_file);
    if (stat(binary_file, &st) != 0) {
        perror("ERROR: Cannot stat binary file");
        return 1;
    }
    DEBUG_PRINT("      Binary size: %ld bytes (0x%lX)\n", st.st_size, st.st_size);

    if (st.st_size > 10*1024*1024) {
        DEBUG_PRINT("ERROR: Binary too large\n");
        return 1;
    }

    map_size = (st.st_size + 4095) & ~4095;
    DEBUG_PRINT("      Will map %zu bytes (page aligned)\n\n", map_size);

    /* Open /dev/mem */
    DEBUG_PRINT("[2/5] Opening /dev/mem...\n");
    mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mem_fd < 0) {
        perror("ERROR: Cannot open /dev/mem");
        return 1;
    }
    DEBUG_PRINT("      OK\n\n");

    /* Map bare-metal memory region */
    DEBUG_PRINT("[3/5] Mapping memory at 0x%08X...\n", BARE_METAL_BASE);
    bare_metal_mem = mmap(NULL,
                          map_size,
                          PROT_READ | PROT_WRITE,
                          MAP_SHARED,
                          mem_fd,
                          BARE_METAL_BASE);

    if (bare_metal_mem == MAP_FAILED) {
        perror("ERROR: mmap failed");
        close(mem_fd);
        return 1;
    }
    DEBUG_PRINT("      OK - mapped to %p\n\n", bare_metal_mem);

    /* Load binary file */
    DEBUG_PRINT("[4/5] Loading binary file...\n");
    fp = fopen(binary_file, "rb");
    if (!fp) {
        perror("ERROR: Cannot open binary file");
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    size_t bytes_read = fread(bare_metal_mem, 1, st.st_size, fp);
    fclose(fp);

    if (bytes_read != st.st_size) {
        DEBUG_PRINT("ERROR: Read %zu bytes, expected %ld\n", bytes_read, st.st_size);
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    DEBUG_PRINT("      OK - Loaded %zu bytes to 0x%08X\n\n", bytes_read, BARE_METAL_BASE);

    /* Clean cache to ensure writes are visible */
    __sync_synchronize();
    msync(bare_metal_mem, map_size, MS_SYNC);

    /* Map spin table region */
    DEBUG_PRINT("[5/5] Waking Core 3 via spin table...\n");
    DEBUG_PRINT("      Spin table address: 0x%08X\n", CORE3_RELEASE_ADDR);

    spin_table_mem = mmap(NULL,
                          4096,
                          PROT_READ | PROT_WRITE,
                          MAP_SHARED,
                          mem_fd,
                          0);  // Map page 0

    if (spin_table_mem == MAP_FAILED) {
        perror("ERROR: Cannot map spin table");
        munmap(bare_metal_mem, map_size);
        close(mem_fd);
        return 1;
    }

    /* Write entry point to Core 3's release address */
    volatile uint64_t *release_addr = (volatile uint64_t *)((char *)spin_table_mem + CORE3_RELEASE_ADDR);

    DEBUG_PRINT("      Writing entry point 0x%08X to release address...\n", BARE_METAL_BASE);
    *release_addr = (uint64_t)BARE_METAL_BASE;
    __sync_synchronize();

    /* Flush cache */
    msync(spin_table_mem, 4096, MS_SYNC);
    __sync_synchronize();

    /* Read back to verify */
    uint64_t readback = *release_addr;
    DEBUG_PRINT("      Readback: 0x%016lX\n", readback);

    /* Send Event to wake Core 3 */
    DEBUG_PRINT("      Sending SEV (Send Event)...\n");
    asm volatile("sev");
    __sync_synchronize();

    DEBUG_PRINT("      OK\n\n");

    /* Wait a moment for Core 3 to start */
    usleep(100000);  // 100ms

    /* Cleanup */
    munmap(spin_table_mem, 4096);
    munmap(bare_metal_mem, map_size);
    close(mem_fd);

    DEBUG_PRINT("====================================\n");
    DEBUG_PRINT("SUCCESS! Core 3 should be running!\n");
    DEBUG_PRINT("Check UART0 output (GPIO 14/15)\n");
    DEBUG_PRINT("====================================\n");

    return 0;
}
