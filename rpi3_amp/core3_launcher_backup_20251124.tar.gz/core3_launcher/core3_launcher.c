/*
 * RPi3 AMP - Core 3 Launcher
 *
 * Purpose: Load bare-metal code to 0x20000000 and wake Core 3
 *
 * Usage: sudo ./core3_launcher <binary_file>
 *
 * Hardware: Raspberry Pi 3 Model B (BCM2837)
 *
 * Memory Map:
 *   0x20000000 - 0x209FFFFF : Reserved for Bare-Metal Code (10 MB)
 *   0x20A00000 - 0x20BFFFFF : Reserved for Shared Memory (2 MB)
 *   0x40000000              : ARM Local Peripherals (Mailboxes!)
 *
 * ARM Local Mailboxes (BCM2836 QA7):
 *   Core 3 Mailbox 3 SET: 0x400000B0
 *   Core 3 Mailbox 3 CLR: 0x400000F0
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

/* Hardware Addresses for RPi3 */
#define ARM_LOCAL_BASE      0x40000000
#define ARM_LOCAL_SIZE      0x1000          // 4 KB

#define BARE_METAL_BASE     0x20000000
#define BARE_METAL_SIZE     0x00A00000      // 10 MB

/* ARM Local Mailbox Offsets */
#define CORE3_MBOX3_SET     0xB0
#define CORE3_MBOX3_CLR     0xF0
#define CORE3_MBOX3_RD      0x70

/* Function prototypes */
static int load_binary(const char *filename, void *dest_addr, size_t max_size, size_t *loaded_size);
static int wake_core3(uint32_t jump_addr);
static void print_usage(const char *prog);

/*
 * Main function
 */
int main(int argc, char *argv[])
{
    int ret = 0;
    size_t binary_size = 0;
    int mem_fd = -1;
    void *bare_metal_mem = NULL;

    printf("====================================\n");
    printf("RPi3 AMP - Core 3 Launcher\n");
    printf("====================================\n\n");

    /* Check arguments */
    if (argc != 2) {
        print_usage(argv[0]);
        return 1;
    }

    const char *binary_file = argv[1];

    /* Open /dev/mem */
    printf("[1/4] Opening /dev/mem...\n");
    mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mem_fd < 0) {
        perror("ERROR: Cannot open /dev/mem (need sudo?)");
        return 1;
    }
    printf("      SUCCESS: /dev/mem opened\n\n");

    /* Map bare-metal memory region */
    printf("[2/4] Mapping memory at 0x%08X...\n", BARE_METAL_BASE);
    bare_metal_mem = mmap(NULL,
                          BARE_METAL_SIZE,
                          PROT_READ | PROT_WRITE,
                          MAP_SHARED,
                          mem_fd,
                          BARE_METAL_BASE);

    if (bare_metal_mem == MAP_FAILED) {
        perror("ERROR: Cannot map bare-metal memory");
        close(mem_fd);
        return 1;
    }
    printf("      SUCCESS: Memory mapped at %p\n", bare_metal_mem);
    printf("      Size: %u MB\n\n", BARE_METAL_SIZE / (1024 * 1024));

    /* Load binary */
    printf("[3/4] Loading binary '%s'...\n", binary_file);
    ret = load_binary(binary_file, bare_metal_mem, BARE_METAL_SIZE, &binary_size);
    if (ret != 0) {
        fprintf(stderr, "ERROR: Failed to load binary\n");
        munmap(bare_metal_mem, BARE_METAL_SIZE);
        close(mem_fd);
        return 1;
    }
    printf("      SUCCESS: Loaded %zu bytes\n", binary_size);
    printf("      Location: 0x%08X - 0x%08lX\n\n",
           BARE_METAL_BASE,
           BARE_METAL_BASE + binary_size - 1);

    /* Memory barrier - ensure all writes are visible */
    __sync_synchronize();

    /* Wake Core 3 */
    printf("[4/4] Waking Core 3...\n");
    ret = wake_core3(BARE_METAL_BASE);
    if (ret != 0) {
        fprintf(stderr, "ERROR: Failed to wake Core 3\n");
        munmap(bare_metal_mem, BARE_METAL_SIZE);
        close(mem_fd);
        return 1;
    }
    printf("      SUCCESS: Core 3 wake signal sent!\n\n");

    /* Cleanup */
    munmap(bare_metal_mem, BARE_METAL_SIZE);
    close(mem_fd);

    printf("====================================\n");
    printf("Core 3 should now be running!\n");
    printf("Check UART0 output on GPIO 14/15\n");
    printf("====================================\n");

    return 0;
}

/*
 * Load binary file to memory
 */
static int load_binary(const char *filename, void *dest_addr, size_t max_size, size_t *loaded_size)
{
    FILE *fp = NULL;
    struct stat st;
    size_t bytes_read;

    /* Check file exists and get size */
    if (stat(filename, &st) != 0) {
        perror("ERROR: Cannot stat binary file");
        return -1;
    }

    if (st.st_size > max_size) {
        fprintf(stderr, "ERROR: Binary too large (%ld bytes, max %zu bytes)\n",
                st.st_size, max_size);
        return -1;
    }

    /* Open file */
    fp = fopen(filename, "rb");
    if (!fp) {
        perror("ERROR: Cannot open binary file");
        return -1;
    }

    /* Read binary into memory */
    bytes_read = fread(dest_addr, 1, st.st_size, fp);
    fclose(fp);

    if (bytes_read != st.st_size) {
        fprintf(stderr, "ERROR: Read %zu bytes, expected %ld\n",
                bytes_read, st.st_size);
        return -1;
    }

    *loaded_size = bytes_read;
    return 0;
}

/*
 * Wake Core 3 via ARM Local Mailbox
 */
static int wake_core3(uint32_t jump_addr)
{
    int mem_fd;
    void *arm_local_mem = NULL;
    volatile uint32_t *mbox_set;
    volatile uint32_t *mbox_clr;
    volatile uint32_t *mbox_rd;

    /* Open /dev/mem */
    mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mem_fd < 0) {
        perror("ERROR: Cannot open /dev/mem");
        return -1;
    }

    /* Map ARM Local peripheral region */
    arm_local_mem = mmap(NULL,
                         ARM_LOCAL_SIZE,
                         PROT_READ | PROT_WRITE,
                         MAP_SHARED,
                         mem_fd,
                         ARM_LOCAL_BASE);

    if (arm_local_mem == MAP_FAILED) {
        perror("ERROR: Cannot map ARM Local peripherals");
        close(mem_fd);
        return -1;
    }

    /* Get mailbox register pointers */
    mbox_set = (volatile uint32_t *)(arm_local_mem + CORE3_MBOX3_SET);
    mbox_clr = (volatile uint32_t *)(arm_local_mem + CORE3_MBOX3_CLR);
    mbox_rd  = (volatile uint32_t *)(arm_local_mem + CORE3_MBOX3_RD);

    /* Clear mailbox first */
    *mbox_clr = 0xFFFFFFFF;
    __sync_synchronize();

    /* Wait a bit */
    usleep(1000);

    /* Write jump address to mailbox */
    printf("      Writing jump address 0x%08X to Core 3 Mailbox 3...\n", jump_addr);
    *mbox_set = jump_addr;
    __sync_synchronize();

    /* Send Event to wake Core 3 from WFE */
    printf("      Sending SEV (Send Event)...\n");
    asm volatile("sev");
    __sync_synchronize();

    /* Verify mailbox was written */
    usleep(1000);
    uint32_t mbox_val = *mbox_rd;
    printf("      Mailbox readback: 0x%08X\n", mbox_val);

    /* Cleanup */
    munmap(arm_local_mem, ARM_LOCAL_SIZE);
    close(mem_fd);

    return 0;
}

/*
 * Print usage information
 */
static void print_usage(const char *prog)
{
    fprintf(stderr, "\nUsage: sudo %s <binary_file>\n\n", prog);
    fprintf(stderr, "Example:\n");
    fprintf(stderr, "  sudo %s core3_amp.bin\n\n", prog);
    fprintf(stderr, "Note: Requires root access to /dev/mem\n\n");
}
