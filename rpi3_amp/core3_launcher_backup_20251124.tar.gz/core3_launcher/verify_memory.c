/*
 * Verify Memory Contents at 0x20000000
 * Check if binary was loaded correctly
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdint.h>

#define BARE_METAL_BASE  0x20000000
#define READ_SIZE        256

int main(void)
{
    int fd;
    void *ptr;
    uint32_t *data;

    printf("Reading first %d bytes from 0x%08X...\n\n", READ_SIZE, BARE_METAL_BASE);

    fd = open("/dev/mem", O_RDONLY | O_SYNC);
    if (fd < 0) {
        perror("ERROR: Cannot open /dev/mem");
        return 1;
    }

    ptr = mmap(NULL, 4096, PROT_READ, MAP_SHARED, fd, BARE_METAL_BASE);
    if (ptr == MAP_FAILED) {
        perror("ERROR: mmap failed");
        close(fd);
        return 1;
    }

    data = (uint32_t *)ptr;

    printf("First 64 words (256 bytes) at 0x%08X:\n", BARE_METAL_BASE);
    printf("========================================\n");

    for (int i = 0; i < 64; i++) {
        if (i % 4 == 0) {
            printf("0x%08X: ", BARE_METAL_BASE + (i * 4));
        }
        printf("%08X ", data[i]);
        if ((i + 1) % 4 == 0) {
            printf("\n");
        }
    }

    printf("========================================\n\n");

    // Check if it looks like ARM code
    if (data[0] != 0 && data[0] != 0xFFFFFFFF) {
        printf("Memory contains data (likely loaded successfully)\n");
    } else {
        printf("WARNING: Memory appears empty or uninitialized\n");
    }

    munmap(ptr, 4096);
    close(fd);

    return 0;
}
