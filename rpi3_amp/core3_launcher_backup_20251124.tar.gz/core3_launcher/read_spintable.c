/* Read Core 3 Spin Table Value */
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdint.h>
#include <unistd.h>

#define CORE3_RELEASE_ADDR  0x000000F0

int main(void) {
    int fd = open("/dev/mem", O_RDONLY | O_SYNC);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    void *mem = mmap(NULL, 4096, PROT_READ, MAP_SHARED, fd, 0);
    if (mem == MAP_FAILED) {
        perror("mmap");
        close(fd);
        return 1;
    }

    volatile uint64_t *release = (volatile uint64_t *)((char *)mem + CORE3_RELEASE_ADDR);
    uint64_t val = *release;

    printf("Core 3 Spin Table (0x%08X): 0x%016lX\n", CORE3_RELEASE_ADDR, val);

    if (val == 0x20000000) {
        printf("SUCCESS: Entry point written correctly!\n");
    } else if (val == 0) {
        printf("WARNING: Spin table is zero (Core 3 may have already started)\n");
    } else {
        printf("UNEXPECTED: Got 0x%lX instead of 0x20000000\n", val);
    }

    munmap(mem, 4096);
    close(fd);
    return 0;
}
