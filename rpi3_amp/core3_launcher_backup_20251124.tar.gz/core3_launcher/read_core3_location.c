/* Check what's at Core 3's current wait address */
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdint.h>
#include <unistd.h>

#define CORE3_ADDR  0x14CF3A0

int main(void) {
    int fd = open("/dev/mem", O_RDONLY | O_SYNC);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    // Map the page containing this address
    uint32_t page_addr = CORE3_ADDR & ~4095;
    uint32_t offset = CORE3_ADDR & 4095;

    void *mem = mmap(NULL, 8192, PROT_READ, MAP_SHARED, fd, page_addr);
    if (mem == MAP_FAILED) {
        perror("mmap");
        close(fd);
        return 1;
    }

    uint32_t *code = (uint32_t *)((char *)mem + offset);

    printf("Code at 0x%08X (Core 3's current location):\n", CORE3_ADDR);
    printf("============================================\n");

    for (int i = 0; i < 16; i++) {
        printf("0x%08X: %08X\n", CORE3_ADDR + (i * 4), code[i]);
    }

    printf("\nThis is where Core 3 is currently waiting/executing.\n");

    munmap(mem, 8192);
    close(fd);
    return 0;
}
