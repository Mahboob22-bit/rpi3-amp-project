# Core 3 Launcher - RPi3 AMP Project

## Overview

The **Core 3 Launcher** is a Linux userspace tool that loads bare-metal code into reserved memory and wakes Core 3 to execute it. This enables Asymmetric Multiprocessing (AMP) on the Raspberry Pi 3, with Linux running on Cores 0-2 and bare-metal code on Core 3.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Raspberry Pi 3 (BCM2837)                  │
├───────────────┬───────────────┬───────────────┬─────────────┤
│   Core 0      │   Core 1      │   Core 2      │   Core 3    │
│   Linux       │   Linux       │   Linux       │  Bare-Metal │
└───────────────┴───────────────┴───────────────┴─────────────┘
       │                                              │
       │      core3_launcher loads binary            │
       │      and sends wake signal                  │
       └─────────────────────────────────────────────┘
```

## Prerequisites

### Phase 1 & 2 Must Be Complete

Before using this tool, you must have completed:

1. **Phase 1: Linux AMP Configuration**
   - `maxcpus=3` in `/boot/firmware/cmdline.txt`
   - `enable_uart=1` in `/boot/firmware/config.txt`
   - `dtoverlay=disable-bt` in `/boot/firmware/config.txt`
   - serial-getty service masked

2. **Phase 2: Memory Reservation**
   - Device tree overlay installed: `rpi3-amp-reserved-memory.dtbo`
   - Memory at 0x20000000 reserved (10 MB for bare-metal)
   - Memory at 0x20A00000 reserved (2 MB for shared IPC)

### Verify Prerequisites

```bash
# Check only 3 cores active
cat /proc/cpuinfo | grep processor
# Should show: processor 0, 1, 2 (NOT 3!)

# Check memory reservation
dmesg | grep -i "amp_code\|amp_shared"
# Should show: "nomap non-reusable amp_code@20000000"
#              "nomap non-reusable amp_shared@20A00000"

# Check device tree nodes
ls -la /proc/device-tree/reserved-memory/
# Should show: amp_code@20000000 and amp_shared@20A00000
```

## Hardware Requirements

- **Raspberry Pi 3 Model B** (BCM2837)
- **USB-UART Adapter** for debugging (FTDI, CP2102, etc.)
- Connections:
  - GPIO 14 (Pin 8) → UART RX
  - GPIO 15 (Pin 10) → UART TX
  - GND → GND

## Building

### On RPi3 (Native Compile)

```bash
cd /home/admin/rpi3_amp/core3_launcher
make
```

### From WSL (Transfer to RPi)

```bash
# Build on WSL (if you have native gcc installed)
cd ~/rpi3_amp_project/rpi3_amp/core3_launcher
make

# Transfer to RPi
scp core3_launcher admin@rpi3-amp:~/
```

## Usage

### Basic Usage

```bash
sudo ./core3_launcher <binary_file>
```

### Example: Launch Bare-Metal Code

```bash
# On RPi3
cd ~/rpi3_amp/core3_launcher
sudo ./core3_launcher ../rpi3_amp_core3/core3_amp.bin
```

**Expected Output:**

```
====================================
RPi3 AMP - Core 3 Launcher
====================================

[1/4] Opening /dev/mem...
      SUCCESS: /dev/mem opened

[2/4] Mapping memory at 0x20000000...
      SUCCESS: Memory mapped at 0x...
      Size: 10 MB

[3/4] Loading binary 'core3_amp.bin'...
      SUCCESS: Loaded 2048 bytes
      Location: 0x20000000 - 0x200007FF

[4/4] Waking Core 3...
      Writing jump address 0x20000000 to Core 3 Mailbox 3...
      Sending SEV (Send Event)...
      Mailbox readback: 0x20000000
      SUCCESS: Core 3 wake signal sent!

====================================
Core 3 should now be running!
Check UART0 output on GPIO 14/15
====================================
```

### Check UART Output

On your development machine with UART adapter connected:

```bash
# Linux
screen /dev/ttyUSB0 115200

# Or
minicom -D /dev/ttyUSB0 -b 115200
```

**Expected UART Output from Core 3:**

```
========================================
*** RPi3 AMP - Core 3 Bare-Metal ***
========================================
Running at: 0x20000000 (AMP Reserved)
UART0: GPIO 14/15 (Pins 8/10)
Core 3 successfully started!
========================================

Message #0
Message #1
Message #2
...
```

## How It Works

### Step-by-Step Process

1. **Open /dev/mem**
   - Requires root access
   - Provides direct physical memory access

2. **Map Reserved Memory**
   - Maps 0x20000000 (10 MB) into userspace
   - This is the reserved bare-metal code region

3. **Load Binary**
   - Reads binary file (e.g., `core3_amp.bin`)
   - Writes it to 0x20000000
   - Maximum size: 10 MB

4. **Wake Core 3**
   - Maps ARM Local peripherals at 0x40000000
   - Writes jump address to Core 3 Mailbox 3 (offset 0xB0)
   - Sends SEV instruction to wake Core 3 from WFE

### Core 3 Boot Sequence

When Core 3 receives the wake signal:

1. Core 3 exits WFE (Wait For Event)
2. Reads Mailbox 3 to get jump address (0x20000000)
3. Jumps to that address
4. Bare-metal code executes:
   - Checks it's Core 3 (via MPIDR_EL1)
   - Sets up stack
   - Clears BSS
   - Calls `main()`
   - Initializes UART0
   - Prints messages

## Memory Map

```
Physical Address Space:

0x00000000 ┌─────────────────────────────────────┐
           │                                     │
           │        Linux RAM (~512 MB)          │
           │        Cores 0, 1, 2                │
           │                                     │
0x1FFFFFFF └─────────────────────────────────────┘

0x20000000 ┌─────────────────────────────────────┐ ← core3_launcher loads binary here
           │  amp_code@20000000                  │
           │  10 MB - Bare-Metal Code/Data       │
           │  nomap - Linux cannot access        │ ← Reserved by Device Tree
           │  Core 3 executes from here          │
0x209FFFFF └─────────────────────────────────────┘

0x20A00000 ┌─────────────────────────────────────┐
           │  amp_shared@20A00000                │
           │  2 MB - Shared Memory (future IPC)  │
           │  nomap - Reserved for OpenAMP       │ ← Reserved by Device Tree
0x20BFFFFF └─────────────────────────────────────┘

0x20C00000 ┌─────────────────────────────────────┐
           │                                     │
           │    Linux RAM continued (~446 MB)    │
           │                                     │
0x3EFFFFFF └─────────────────────────────────────┘

0x3F000000   BCM2837 Peripherals (GPIO, UART, etc.)
0x40000000   ARM Local Peripherals (Mailboxes!)
```

## ARM Local Mailboxes (BCM2836 QA7)

The launcher uses ARM Local Mailbox 3 to communicate with Core 3:

| Register | Offset | Address | Purpose |
|----------|--------|---------|---------|
| CORE3_MBOX3_SET | 0xB0 | 0x400000B0 | Write data to Core 3 Mailbox 3 |
| CORE3_MBOX3_CLR | 0xF0 | 0x400000F0 | Clear Core 3 Mailbox 3 |
| CORE3_MBOX3_RD | 0x70 | 0x40000070 | Read Core 3 Mailbox 3 |

**Wake Protocol:**
1. Clear mailbox: `CORE3_MBOX3_CLR = 0xFFFFFFFF`
2. Write jump address: `CORE3_MBOX3_SET = 0x20000000`
3. Send event: `asm volatile("sev")`
4. Core 3 wakes from WFE and jumps to address

## Troubleshooting

### Permission Denied

```
ERROR: Cannot open /dev/mem (need sudo?)
```

**Solution:** Run with `sudo`:
```bash
sudo ./core3_launcher core3_amp.bin
```

### Cannot Map Memory

```
ERROR: Cannot map bare-metal memory
```

**Solution:** Verify memory reservation in Phase 2:
```bash
dmesg | grep amp_code
# Should show: "amp_code@20000000" with "nomap"
```

### Binary Too Large

```
ERROR: Binary too large (12000000 bytes, max 10485760 bytes)
```

**Solution:** Binary must be ≤10 MB. Check linker script and code size.

### No UART Output

**Possible Causes:**

1. **UART not configured** (Phase 1 incomplete)
   ```bash
   # Check config.txt
   cat /boot/firmware/config.txt | grep uart
   # Should have: enable_uart=1 and dtoverlay=disable-bt
   ```

2. **Wrong UART pins**
   - Ensure GPIO 14/15 (Physical Pins 8/10)
   - Check wiring: RX↔TX, TX↔RX, GND↔GND

3. **Wrong baud rate**
   - Use 115200 baud
   - Check bare-metal code: `UART0_IBRD = 26; UART0_FBRD = 3;`

4. **Core 3 not waking**
   ```bash
   # Check if launcher completed successfully
   # Check mailbox readback in launcher output
   ```

### Core 3 Not Running

**Check Boot Code:**
- Verify `boot.S` checks for Core 3: `cmp x0, #3`
- Verify Core 3 isn't halting immediately

**Check Linker Script:**
- Verify start address: `. = 0x20000000;`

**Verify Load Address:**
- Launcher output shows: `Location: 0x20000000 - ...`

## Testing Phase 3

### Complete Test Procedure

```bash
# 1. Verify prerequisites
cat /proc/cpuinfo | grep processor  # Only 0, 1, 2
dmesg | grep amp_code               # Shows "nomap"

# 2. Build bare-metal code (if not done)
cd ~/rpi3_amp/rpi3_amp_core3
make clean
make

# 3. Build launcher
cd ~/rpi3_amp/core3_launcher
make clean
make

# 4. Connect UART adapter
# GPIO 14 → RX, GPIO 15 → TX, GND → GND

# 5. Open UART terminal on dev machine
screen /dev/ttyUSB0 115200

# 6. Launch Core 3
sudo ./core3_launcher ../rpi3_amp_core3/core3_amp.bin

# 7. Check UART output
# Should see banner and counting messages
```

### Success Criteria

- [x] Launcher completes without errors
- [x] Memory mapped successfully (10 MB)
- [x] Binary loaded (shows size and address)
- [x] Mailbox readback shows jump address (0x20000000)
- [x] UART shows Core 3 banner message
- [x] UART shows incrementing message counter

## Next Steps: Phase 4

After Phase 3 is working:

1. **OpenAMP Integration**
   - Port libmetal for RPi3
   - Port OpenAMP platform layer
   - Implement RPMsg channels

2. **Bidirectional Communication**
   - Shared memory ring buffers
   - Linux ↔ Core 3 messaging
   - Interrupt-based notifications

3. **Stability Testing**
   - Long-duration tests
   - Cache coherency verification
   - Performance measurements

## References

- **BCM2836 ARM Local Peripherals (QA7)** - Mailbox documentation
- **BCM2835 ARM Peripherals** - GPIO, UART documentation
- **Project Documentation:**
  - `CLAUDE.md` - Project overview
  - `rpi3_amp_documentation.md` - Complete technical docs
  - `PHASE1_COMPLETE.md` - Phase 1 results
  - `PHASE2_COMPLETE.md` - Phase 2 results

## SSH Access

```bash
ssh admin@rpi3-amp
```

Default directory: `/home/admin/rpi3_amp/`

---

**Phase 3 Goal:** Linux and bare-metal code running simultaneously on RPi3!

**Status:** Ready to test! 🚀
